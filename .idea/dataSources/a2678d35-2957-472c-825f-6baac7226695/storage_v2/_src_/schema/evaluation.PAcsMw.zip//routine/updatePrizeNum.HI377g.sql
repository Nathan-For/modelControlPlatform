create
    definer = root@`%` procedure updatePrizeNum()
BEGIN
	#Routine body goes here...
#declare s INT;
	if CURDATE() = DATE('2019-03-23') then 
			 update lottery_award set today_num=20 ,today_remain_num=20 ,remain_num=20 WHERE id =1; # 免费券
			 update lottery_award set today_num=4 ,today_remain_num=4,remain_num=4 WHERE id =3;  #健康豆
			 update lottery_award set today_num=240 ,today_remain_num=240 ,remain_num=240 WHERE id =5;  #优惠套餐
			 update lottery_award set today_num=1 ,today_remain_num=1  WHERE id =4; #陪人卡  
	elseif CURDATE()>= DATE('2019-03-24') and CURDATE()<= DATE('2019-03-29') then 
			 update lottery_award set today_num=10 ,today_remain_num=10 ,remain_num=10 WHERE id =1; # 免费券
			 update lottery_award set today_num=2 ,today_remain_num=2,remain_num=2 WHERE id =3;  #健康豆
			 update lottery_award set today_num=120 ,today_remain_num=120 ,remain_num=120 WHERE id =5;  #优惠套餐
			 update lottery_award set today_num=1 ,today_remain_num=1  WHERE id =4; #陪人卡  
	ELSEIF CURDATE()>= DATE('2019-03-30') and CURDATE()<= DATE('2019-03-31') then 
			 update lottery_award set today_num=5 ,today_remain_num=5 ,remain_num=5 WHERE id =1; # 免费券
			 update lottery_award set today_num=1 ,today_remain_num=1,remain_num=1 WHERE id =3;  #健康豆
			 update lottery_award set today_num=60 ,today_remain_num=60 ,remain_num=60 WHERE id =5;  #优惠套餐
			 update lottery_award set today_num=1 ,today_remain_num=1  WHERE id =4; #陪人卡 
	ELSEIF CURDATE()= DATE('2019-04-01') then 
			 update lottery_award set today_num=20 ,today_remain_num=20 ,remain_num=20 WHERE id =1; # 免费券
			 update lottery_award set today_num=4 ,today_remain_num=4,remain_num=4 WHERE id =3;  #健康豆
			 update lottery_award set today_num=240 ,today_remain_num=240 ,remain_num=240 WHERE id =5;  #优惠套餐
			 update lottery_award set today_num=1 ,today_remain_num=1  WHERE id =4; #陪人卡
	ELSEIF CURDATE()>= DATE('2019-03-24') and CURDATE()<= DATE('2019-03-29') THEN
			 update lottery_award set today_num=10 ,today_remain_num=10 ,remain_num=10 WHERE id =1; # 免费券
			 update lottery_award set today_num=2 ,today_remain_num=2,remain_num=2 WHERE id =3;  #健康豆
			 update lottery_award set today_num=120 ,today_remain_num=120 ,remain_num=120 WHERE id =5;  #优惠套餐
			 update lottery_award set today_num=1 ,today_remain_num=1  WHERE id =4; #陪人卡    
	
	end if;
END;

