create
    definer = root@`%` procedure insert_test_val(IN num_limit int)
BEGIN

DECLARE i int default 1;
DECLARE c varchar(255) default '';
 
WHILE i<=num_limit do
 

set c = '\双\叶\甲\状\腺\回\声\减\低\，\内\见\多\个(低回声|中回声)\结\节\，\最\大\约.*\c\m\，\内\呈\点\状\回\声\，\结\节\周\边\有\血\管\环\绕\。\峡\部\厚\约\7\m\m\。\C\D\F\I\：\血\流\信\号\丰\富';
INSERT into diagnose.zz values (null,c);
set i = i + 1;
 
END WHILE;
 
END;

