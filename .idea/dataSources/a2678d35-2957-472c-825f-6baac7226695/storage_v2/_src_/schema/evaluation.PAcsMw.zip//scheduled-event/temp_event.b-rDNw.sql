create definer = root@`%` event temp_event on schedule
    every '1' DAY
        starts '2019-03-23 00:00:00'
    on completion preserve
    enable
    do
    CALL proc_sendAllMsg;

