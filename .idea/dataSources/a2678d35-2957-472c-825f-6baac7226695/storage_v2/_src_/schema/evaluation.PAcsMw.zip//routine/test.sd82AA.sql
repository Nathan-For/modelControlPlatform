create
    definer = root@`%` procedure test()
BEGIN
	DECLARE num INT DEFAULT 1;
	while num<1000 do 
		select er.id, er.user_id, er.is_owner, er.nick_name, er.ep_id, er.qp_id, er.status, er.		score, er.grade, er.er_no, er.`desc`, er.create_time from ev_record er inner join 				ev_project ep on er.ep_id=ep.id where er.user_id=22 and ep.type="thyroid" and er.status in(2) order by 	er.create_time desc limit 1;
		set num = num+1;
	end while;
end;

