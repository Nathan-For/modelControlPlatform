create
    definer = root@`%` procedure handleTemplate()
BEGIN
			DECLARE i INT(8);#模板数量
  
			DECLARE j INT(8);#特征数量

			DECLARE countj INT(8);#

			DECLARE templateid INT(8);#模板id

			DECLARE template text;#模板

      SELECT COUNT(*) INTO i FROM thyroid_template;

			SELECT COUNT(*) INTO j FROM thyroid_feature;
			
			while i>=0  do
				set i=i-1;				
				SELECT id,raw_content INTO templateid,template FROM thyroid_template limit i,1;
				#IF template is not null THEN
					set countj=j;
					while countj>=0  do
						set countj=countj-1;
						SELECT REPLACE(template, feature_name, feature_regexp) INTO template FROM thyroid_feature limit countj,1;
					end while;

					UPDATE thyroid_template set reg_content=template WHERE id=templateid;	
				#END IF;
			end while;

		 UPDATE thyroid_template set reg_content= REPLACE(reg_content,'c','C');	
		 UPDATE thyroid_template set reg_content= REPLACE(reg_content,'m','M');	
END;

