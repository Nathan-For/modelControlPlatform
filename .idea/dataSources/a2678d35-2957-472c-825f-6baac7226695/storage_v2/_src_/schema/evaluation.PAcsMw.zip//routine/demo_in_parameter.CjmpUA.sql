create
    definer = root@`%` procedure demo_in_parameter(IN p_in int)
BEGIN   
    SELECT p_in;   
    SET p_in=2;   
    SELECT p_in;   
    END;

